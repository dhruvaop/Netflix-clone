import React from "react";

const Footer = () => {
  return (
    <footer>
      <p>Movies database made with React</p>
    </footer>
  );
};

export default Footer;
